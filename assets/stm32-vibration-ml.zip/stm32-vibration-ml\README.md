# STM32 Vibration Fault Classifier

A portfolio-sized embedded ML project that classifies four simulated motor
conditions from a 256-sample vibration window:

- healthy
- imbalance
- misalignment
- bearing fault

The project is deliberately small enough to understand end to end. The Python
code generates training signals, extracts the same features used in firmware,
trains a decision tree, and exports readable C. The firmware side has no dynamic
allocation and processes one sample at a time.

## Why this project

It combines the skills expected in an entry-level embedded AI role:

- timer-driven sampling
- deterministic buffering
- DSP-oriented feature extraction
- supervised classification
- model export to C
- host/firmware parity tests
- latency, memory, and failure-mode reasoning

The architecture was inspired by the separation of preprocessing and generated
models in the open-source [emlearn](https://github.com/emlearn/emlearn)
motion-recognition examples. This implementation is original and intentionally
uses a transparent decision tree rather than copying upstream code.

## Repository layout

```text
training/train.py                 dataset, features, CART training, C export
firmware/include/                 public firmware interfaces
firmware/src/                     portable feature and application code
firmware/generated/model.h        generated readable classifier
firmware/ports/                   STM32 HAL integration template
tests/host_test.c                 C/Python parity test
data/test_vectors.csv             generated verification windows
docs/interview-guide.md           how to explain every design choice
docs/hardware-bringup.md          path from simulation to a physical sensor
```

## Run it

Requirements:

- Python 3.10 or newer; no third-party Python packages
- GCC or Clang for the host test

From the repository root:

```powershell
python training/train.py
gcc -std=c11 -O2 -Wall -Wextra -pedantic `
  -Ifirmware/include -Ifirmware/generated `
  firmware/src/vibration_features.c firmware/src/vibration_app.c `
  tests/host_test.c -lm -o build/host_test.exe
./build/host_test.exe data/test_vectors.csv
```

On Linux/macOS, `make verify` performs the same steps.

## Hardware assumptions

The reference configuration uses:

- 1 kHz sample rate
- 256 samples per window
- one vibration axis expressed in `g`
- motor fundamental near 50 Hz

These values are not universal. Update `VIB_SAMPLE_RATE_HZ`, retrain the model,
and collect real data for your motor and sensor.

## What is real and what is simulated

The complete data-to-C pipeline and firmware execution are real. The included
dataset is synthetic so the repository is immediately reproducible. A résumé
version of the project should add measurements from a real accelerometer and
motor; synthetic accuracy must never be presented as field performance.

## Suggested résumé bullet after hardware validation

> Developed an STM32 motor-condition classifier using timer-driven
> accelerometer sampling, embedded vibration features, and an exported
> decision-tree model; verified Python/C prediction parity and measured
> inference latency, RAM, and flash usage.

## License

MIT. See [LICENSE](LICENSE).
