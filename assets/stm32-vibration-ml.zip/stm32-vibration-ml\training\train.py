"""Train and export a transparent motor-vibration decision tree.

Only the Python standard library is used. This keeps the project reproducible
and makes the learning algorithm inspectable.
"""

from __future__ import annotations

import csv
import json
import math
import random
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODEL_HEADER = ROOT / "firmware" / "generated" / "model.h"
MODEL_JSON = ROOT / "firmware" / "generated" / "model.json"
TEST_VECTORS = ROOT / "data" / "test_vectors.csv"

SAMPLE_RATE_HZ = 1000.0
WINDOW_SIZE = 256
CLASS_NAMES = ("healthy", "imbalance", "misalignment", "bearing_fault")
FEATURE_NAMES = (
    "rms",
    "peak",
    "peak_to_peak",
    "crest_factor",
    "mean_abs_diff",
    "zero_cross_rate",
    "power_50_hz",
    "power_100_hz",
    "power_200_hz",
    "kurtosis",
)


def goertzel_power(samples: list[float], frequency_hz: float) -> float:
    omega = 2.0 * math.pi * frequency_hz / SAMPLE_RATE_HZ
    coefficient = 2.0 * math.cos(omega)
    s_prev = 0.0
    s_prev2 = 0.0
    for sample in samples:
        state = sample + coefficient * s_prev - s_prev2
        s_prev2 = s_prev
        s_prev = state
    return s_prev2 * s_prev2 + s_prev * s_prev - coefficient * s_prev * s_prev2


def extract_features(raw: list[float]) -> list[float]:
    mean = sum(raw) / len(raw)
    x = [value - mean for value in raw]
    energy = sum(value * value for value in x)
    rms = math.sqrt(energy / len(x))
    peak = max(abs(value) for value in x)
    peak_to_peak = max(x) - min(x)
    crest = peak / max(rms, 1e-9)
    mean_abs_diff = sum(abs(x[i] - x[i - 1]) for i in range(1, len(x))) / (len(x) - 1)
    zero_crossings = sum((x[i] >= 0.0) != (x[i - 1] >= 0.0) for i in range(1, len(x)))
    zero_cross_rate = zero_crossings / (len(x) - 1)
    normalized_powers = [
        goertzel_power(x, frequency) / max(energy * len(x), 1e-9)
        for frequency in (50.0, 100.0, 200.0)
    ]
    fourth_moment = sum(value ** 4 for value in x) / len(x)
    kurtosis = fourth_moment / max(rms ** 4, 1e-9)
    return [
        rms,
        peak,
        peak_to_peak,
        crest,
        mean_abs_diff,
        zero_cross_rate,
        *normalized_powers,
        kurtosis,
    ]


def generate_window(label: int, rng: random.Random) -> list[float]:
    fundamental = rng.uniform(47.0, 53.0)
    phase = rng.uniform(0.0, 2.0 * math.pi)
    amplitude = rng.uniform(0.075, 0.105)
    noise = rng.uniform(0.010, 0.018)
    samples = []

    for i in range(WINDOW_SIZE):
        t = i / SAMPLE_RATE_HZ
        value = amplitude * math.sin(2.0 * math.pi * fundamental * t + phase)
        value += 0.018 * math.sin(2.0 * math.pi * 2.0 * fundamental * t + 0.4)

        if label == 1:  # imbalance: unusually strong once-per-revolution energy
            value += rng.uniform(0.10, 0.16) * math.sin(
                2.0 * math.pi * fundamental * t + phase
            )
        elif label == 2:  # misalignment: strong second harmonic
            value += rng.uniform(0.11, 0.16) * math.sin(
                2.0 * math.pi * 2.0 * fundamental * t + 1.1
            )
        elif label == 3:  # bearing fault: periodic impacts excite a resonance
            impact_period = max(8, int(SAMPLE_RATE_HZ / rng.uniform(38.0, 46.0)))
            age = i % impact_period
            if age < 12:
                value += 0.20 * math.exp(-age / 4.0) * math.sin(
                    2.0 * math.pi * 200.0 * t
                )

        value += rng.gauss(0.0, noise)
        samples.append(value)
    return samples


@dataclass
class Node:
    prediction: int
    feature: int | None = None
    threshold: float | None = None
    left: "Node | None" = None
    right: "Node | None" = None


def gini(labels: list[int]) -> float:
    if not labels:
        return 0.0
    counts = [labels.count(index) for index in range(len(CLASS_NAMES))]
    return 1.0 - sum((count / len(labels)) ** 2 for count in counts)


def majority(labels: list[int]) -> int:
    return max(range(len(CLASS_NAMES)), key=lambda index: labels.count(index))


def build_tree(
    rows: list[tuple[list[float], int]],
    depth: int = 0,
    max_depth: int = 6,
    min_leaf: int = 10,
) -> Node:
    labels = [label for _, label in rows]
    node = Node(prediction=majority(labels))
    if depth >= max_depth or len(set(labels)) == 1 or len(rows) < 2 * min_leaf:
        return node

    best_score = float("inf")
    best_split = None
    for feature in range(len(FEATURE_NAMES)):
        values = sorted({features[feature] for features, _ in rows})
        if len(values) > 40:
            step = len(values) / 40.0
            values = [values[int(i * step)] for i in range(1, 40)]
        thresholds = [(a + b) * 0.5 for a, b in zip(values, values[1:])]
        for threshold in thresholds:
            left = [row for row in rows if row[0][feature] <= threshold]
            right = [row for row in rows if row[0][feature] > threshold]
            if len(left) < min_leaf or len(right) < min_leaf:
                continue
            score = (len(left) * gini([r[1] for r in left]) +
                     len(right) * gini([r[1] for r in right])) / len(rows)
            if score < best_score:
                best_score = score
                best_split = feature, threshold, left, right

    if best_split is None or best_score >= gini(labels) - 1e-9:
        return node
    node.feature, node.threshold, left_rows, right_rows = best_split
    node.left = build_tree(left_rows, depth + 1, max_depth, min_leaf)
    node.right = build_tree(right_rows, depth + 1, max_depth, min_leaf)
    return node


def predict(node: Node, features: list[float]) -> int:
    while node.feature is not None:
        node = node.left if features[node.feature] <= node.threshold else node.right
        assert node is not None
    return node.prediction


def node_to_dict(node: Node) -> dict:
    result = {"prediction": node.prediction}
    if node.feature is not None:
        result.update(
            feature=node.feature,
            feature_name=FEATURE_NAMES[node.feature],
            threshold=node.threshold,
            left=node_to_dict(node.left),
            right=node_to_dict(node.right),
        )
    return result


def emit_c_node(node: Node, indent: int = 1) -> list[str]:
    pad = "    " * indent
    if node.feature is None:
        return [f"{pad}return {node.prediction}; /* {CLASS_NAMES[node.prediction]} */"]
    lines = [f"{pad}if (features[{node.feature}] <= {node.threshold:.9g}f) {{"]
    lines.extend(emit_c_node(node.left, indent + 1))
    lines.append(f"{pad}}} else {{")
    lines.extend(emit_c_node(node.right, indent + 1))
    lines.append(f"{pad}}}")
    return lines


def export_header(tree: Node) -> None:
    lines = [
        "/* Generated by training/train.py. Do not edit by hand. */",
        "#ifndef VIBRATION_MODEL_H",
        "#define VIBRATION_MODEL_H",
        "",
        "enum vib_class {",
        "    VIB_HEALTHY = 0,",
        "    VIB_IMBALANCE = 1,",
        "    VIB_MISALIGNMENT = 2,",
        "    VIB_BEARING_FAULT = 3",
        "};",
        "",
        "static inline int vibration_model_predict(const float features[10])",
        "{",
    ]
    lines.extend(emit_c_node(tree))
    lines.extend(["}", "", "#endif", ""])
    MODEL_HEADER.parent.mkdir(parents=True, exist_ok=True)
    MODEL_HEADER.write_text("\n".join(lines), encoding="utf-8")
    MODEL_JSON.write_text(json.dumps(node_to_dict(tree), indent=2), encoding="utf-8")


def confusion_matrix(tree: Node, rows: list[tuple[list[float], int]]) -> list[list[int]]:
    matrix = [[0] * len(CLASS_NAMES) for _ in CLASS_NAMES]
    for features, actual in rows:
        matrix[actual][predict(tree, features)] += 1
    return matrix


def main() -> None:
    rng = random.Random(20260620)
    raw_rows = []
    for label in range(len(CLASS_NAMES)):
        for _ in range(320):
            window = generate_window(label, rng)
            raw_rows.append((window, label))
    rng.shuffle(raw_rows)
    split = int(len(raw_rows) * 0.75)
    train_raw, test_raw = raw_rows[:split], raw_rows[split:]
    train_rows = [(extract_features(x), y) for x, y in train_raw]
    test_rows = [(extract_features(x), y) for x, y in test_raw]

    tree = build_tree(train_rows)
    matrix = confusion_matrix(tree, test_rows)
    correct = sum(matrix[i][i] for i in range(len(CLASS_NAMES)))
    accuracy = correct / len(test_rows)
    print(f"test accuracy: {accuracy:.3f} ({correct}/{len(test_rows)})")
    print("rows=actual, columns=predicted")
    for name, row in zip(CLASS_NAMES, matrix):
        print(f"{name:14s} {row}")

    export_header(tree)
    TEST_VECTORS.parent.mkdir(parents=True, exist_ok=True)
    with TEST_VECTORS.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["expected", *[f"s{i}" for i in range(WINDOW_SIZE)]])
        for window, label in test_raw[:80]:
            writer.writerow([label, *[f"{value:.9g}" for value in window]])
    print(f"wrote {MODEL_HEADER.relative_to(ROOT)}")
    print(f"wrote {TEST_VECTORS.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
