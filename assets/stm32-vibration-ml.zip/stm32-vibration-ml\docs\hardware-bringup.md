# Hardware bring-up

## Phase 1: verify the sensor

1. Read the sensor identity register.
2. Record stationary samples and confirm the gravity axis is near 1 g.
3. Estimate zero-g offsets for each axis.
4. Confirm the configured output data rate is at least 1 kHz.
5. Log raw data before adding the classifier.

A digital accelerometer with SPI is preferable at 1 kHz because timing and bus
occupancy are easier to control than with slow I2C settings.

## Phase 2: make sampling deterministic

Use a hardware timer rather than delays or a SysTick-polled loop. Timestamp a
GPIO at acquisition start and inspect it with a logic analyzer. Measure:

- mean sample period
- maximum jitter
- missed samples
- ISR execution time

For a DMA-capable sensor, use ping-pong buffers. The interrupt should switch or
publish a completed buffer; feature extraction belongs in the main loop or a
lower-priority task.

## Phase 3: collect a real dataset

Record separate sessions for every condition. Do not randomly split adjacent
windows from one recording between training and testing; that leaks nearly
identical data into both sets. Split by recording session or physical trial.

Store metadata with every capture:

- motor and sensor identifier
- RPM/load
- mounting position and orientation
- sample rate and sensor range
- fault condition
- date/session identifier

## Phase 4: retrain

Replace `generate_window()` in `training/train.py` with a CSV loader. Preserve
`extract_features()` so Python and firmware continue to use identical feature
definitions. Compare the generated header and run the host test after retraining.

## Phase 5: profile on target

Measure with the Cortex-M cycle counter when available:

```c
DWT->CYCCNT = 0;
DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
uint32_t start = DWT->CYCCNT;
/* extract features and predict */
uint32_t cycles = DWT->CYCCNT - start;
```

Also record `.text`, `.data`, `.bss`, maximum stack use, and supply current.
