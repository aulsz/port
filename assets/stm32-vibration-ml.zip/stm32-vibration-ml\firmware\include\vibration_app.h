#ifndef VIBRATION_APP_H
#define VIBRATION_APP_H

#include <stdbool.h>
#include <stddef.h>
#include "vibration_features.h"

struct vibration_result {
    int class_id;
    float features[VIB_FEATURE_COUNT];
    unsigned long sequence;
};

struct vibration_app {
    float samples[VIB_WINDOW_SIZE];
    size_t write_index;
    unsigned long sequence;
};

void vibration_app_init(struct vibration_app *app);
bool vibration_app_push_sample(
    struct vibration_app *app,
    float acceleration_g,
    struct vibration_result *result);
const char *vibration_class_name(int class_id);

#endif
