/*
 * Integration template, not a complete CubeMX project.
 *
 * Recommended hardware flow:
 *   TIM interrupt at 1 kHz -> start/read accelerometer sample
 *   DMA/SPI completion     -> convert raw count to g -> push sample
 *   completed window       -> report result from the main loop
 *
 * Keep classification out of the interrupt. The ISR should only acquire or
 * enqueue data so its worst-case execution time stays bounded.
 */

#ifdef VIBRATION_ENABLE_STM32_HAL_EXAMPLE

#include "main.h"
#include "vibration_app.h"

extern UART_HandleTypeDef huart2;
static struct vibration_app app;
static volatile bool result_ready;
static struct vibration_result latest_result;

/* Replace this stub with your sensor driver and calibration equation. */
static float accelerometer_read_axis_g(void)
{
    return 0.0f;
}

void vibration_port_init(void)
{
    vibration_app_init(&app);
    result_ready = false;
}

/* Call from a 1 kHz timer callback after the sensor sample is available. */
void vibration_port_sample_tick(void)
{
    const float acceleration_g = accelerometer_read_axis_g();
    if (vibration_app_push_sample(&app, acceleration_g, &latest_result)) {
        result_ready = true;
    }
}

/* Call repeatedly from main(). Formatting is intentionally outside the ISR. */
void vibration_port_process(void)
{
    if (!result_ready) {
        return;
    }
    result_ready = false;
    /* Add snprintf/UART logging here, or publish a compact binary packet. */
}

#endif
