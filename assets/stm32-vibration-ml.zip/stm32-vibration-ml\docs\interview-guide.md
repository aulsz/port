# Interview guide

## Thirty-second explanation

“I built a complete embedded classification pipeline for motor vibration. A
1 kHz stream is divided into 256-sample windows. Firmware removes DC, extracts
time-domain and targeted frequency features, then evaluates a small decision
tree exported from Python. I used identical Python and C feature definitions
and generated test vectors to verify that host firmware predictions match the
training pipeline. The included data is simulated, and the next step is
session-separated validation with a physical accelerometer and motor.”

## Questions you should be able to answer

### Why 1 kHz?

It represents frequencies below 500 Hz without aliasing. The current features
target 50, 100, and 200 Hz. A real design would choose the rate from the
machine’s expected fault spectrum and the accelerometer’s analog/digital
filtering.

### Why 256 samples?

At 1 kHz it gives 256 ms of evidence and fits conveniently in MCU memory.
Longer windows improve frequency resolution but increase detection latency and
RAM use.

### Why remove the mean?

DC offset includes sensor bias and gravity. Removing it makes vibration features
less sensitive to mounting orientation and calibration error.

### What does each feature detect?

- RMS: overall vibration energy
- peak and peak-to-peak: extreme motion
- crest factor: impulsiveness relative to average energy
- mean absolute difference: rapid sample-to-sample change
- zero-crossing rate: rough frequency/noise content
- 50/100/200 Hz power: fundamental, harmonic, and resonance energy
- kurtosis: impulsive heavy-tailed behavior often associated with impacts

### Why Goertzel rather than an FFT?

Only three frequencies are needed. Goertzel evaluates selected frequencies
with less code and storage. If the fault frequencies or motor speed varied
widely, an FFT or order-tracking approach would be more appropriate.

### Why a decision tree?

It has predictable execution, no dynamic allocation, readable generated C, and
very low inference cost. Its weakness is sensitivity to training data and
piecewise-constant boundaries. A random forest or quantized neural network is a
reasonable later comparison.

### What is the biggest limitation?

The supplied dataset is synthetic. It proves software integration, not real
diagnostic accuracy. Sensor mounting, RPM, motor construction, load, and
environmental noise can all shift the feature distribution.

### How did you avoid Python/C mismatch?

The equations and constants are mirrored, the Python pipeline exports raw test
windows, and a host-compiled C test processes those windows through the actual
firmware modules and checks every predicted class.

## Honest résumé language

Before real hardware validation, call it a “reproducible embedded ML prototype
using simulated vibration signals.” After collecting real data, report the
dataset size, session-based test method, accuracy/F1, latency, flash, RAM, and
power. Never report synthetic test accuracy as equipment-fault accuracy.
