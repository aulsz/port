#include "vibration_features.h"

#include <float.h>
#include <math.h>

#define VIB_PI 3.14159265358979323846f

static float goertzel_power(const float *samples, float frequency_hz)
{
    const float omega = 2.0f * VIB_PI * frequency_hz / VIB_SAMPLE_RATE_HZ;
    const float coefficient = 2.0f * cosf(omega);
    float previous = 0.0f;
    float previous_two = 0.0f;

    for (size_t i = 0; i < VIB_WINDOW_SIZE; ++i) {
        const float state = samples[i] + coefficient * previous - previous_two;
        previous_two = previous;
        previous = state;
    }
    return previous_two * previous_two + previous * previous
         - coefficient * previous * previous_two;
}

void vibration_extract_features(
    const float samples[VIB_WINDOW_SIZE],
    float features[VIB_FEATURE_COUNT])
{
    float centered[VIB_WINDOW_SIZE];
    float mean = 0.0f;
    float energy = 0.0f;
    float peak = 0.0f;
    float minimum = FLT_MAX;
    float maximum = -FLT_MAX;
    float absolute_difference = 0.0f;
    float fourth_moment = 0.0f;
    unsigned int zero_crossings = 0u;

    for (size_t i = 0; i < VIB_WINDOW_SIZE; ++i) {
        mean += samples[i];
    }
    mean /= (float)VIB_WINDOW_SIZE;

    for (size_t i = 0; i < VIB_WINDOW_SIZE; ++i) {
        const float value = samples[i] - mean;
        const float absolute = fabsf(value);
        centered[i] = value;
        energy += value * value;
        fourth_moment += value * value * value * value;
        if (absolute > peak) {
            peak = absolute;
        }
        if (value < minimum) {
            minimum = value;
        }
        if (value > maximum) {
            maximum = value;
        }
        if (i > 0u) {
            absolute_difference += fabsf(value - centered[i - 1u]);
            if ((value >= 0.0f) != (centered[i - 1u] >= 0.0f)) {
                ++zero_crossings;
            }
        }
    }

    const float rms = sqrtf(energy / (float)VIB_WINDOW_SIZE);
    const float safe_rms = fmaxf(rms, 1.0e-9f);
    const float normalized_energy = fmaxf(energy * (float)VIB_WINDOW_SIZE, 1.0e-9f);

    features[VIB_FEATURE_RMS] = rms;
    features[VIB_FEATURE_PEAK] = peak;
    features[VIB_FEATURE_PEAK_TO_PEAK] = maximum - minimum;
    features[VIB_FEATURE_CREST_FACTOR] = peak / safe_rms;
    features[VIB_FEATURE_MEAN_ABS_DIFF] =
        absolute_difference / (float)(VIB_WINDOW_SIZE - 1u);
    features[VIB_FEATURE_ZERO_CROSS_RATE] =
        (float)zero_crossings / (float)(VIB_WINDOW_SIZE - 1u);
    features[VIB_FEATURE_POWER_50_HZ] =
        goertzel_power(centered, 50.0f) / normalized_energy;
    features[VIB_FEATURE_POWER_100_HZ] =
        goertzel_power(centered, 100.0f) / normalized_energy;
    features[VIB_FEATURE_POWER_200_HZ] =
        goertzel_power(centered, 200.0f) / normalized_energy;
    features[VIB_FEATURE_KURTOSIS] =
        (fourth_moment / (float)VIB_WINDOW_SIZE) /
        fmaxf(rms * rms * rms * rms, 1.0e-9f);
}
