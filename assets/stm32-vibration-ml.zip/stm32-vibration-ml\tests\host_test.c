#include "vibration_app.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int test_file(const char *path)
{
    FILE *file = fopen(path, "r");
    char line[16384];
    int total = 0;
    int correct = 0;

    if (file == NULL) {
        fprintf(stderr, "cannot open %s\n", path);
        return 1;
    }
    if (fgets(line, sizeof line, file) == NULL) {
        fclose(file);
        return 1;
    }

    while (fgets(line, sizeof line, file) != NULL) {
        char *token = strtok(line, ",");
        struct vibration_app app;
        struct vibration_result result = {0};
        int expected;

        if (token == NULL) {
            continue;
        }
        expected = atoi(token);
        vibration_app_init(&app);

        for (size_t i = 0; i < VIB_WINDOW_SIZE; ++i) {
            token = strtok(NULL, ",");
            if (token == NULL) {
                fprintf(stderr, "short row at test %d\n", total);
                fclose(file);
                return 1;
            }
            (void)vibration_app_push_sample(&app, strtof(token, NULL), &result);
        }
        ++total;
        if (result.class_id == expected) {
            ++correct;
        } else {
            printf("mismatch %d: expected=%s actual=%s\n",
                   total,
                   vibration_class_name(expected),
                   vibration_class_name(result.class_id));
        }
    }
    fclose(file);
    printf("host parity: %d/%d correct (%.1f%%)\n",
           correct, total, total ? 100.0 * correct / total : 0.0);
    return correct == total ? 0 : 1;
}

int main(int argc, char **argv)
{
    if (argc != 2) {
        fprintf(stderr, "usage: %s data/test_vectors.csv\n", argv[0]);
        return 2;
    }
    return test_file(argv[1]);
}
