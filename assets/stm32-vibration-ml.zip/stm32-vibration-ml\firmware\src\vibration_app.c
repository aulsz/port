#include "vibration_app.h"
#include "model.h"

void vibration_app_init(struct vibration_app *app)
{
    app->write_index = 0u;
    app->sequence = 0u;
}

bool vibration_app_push_sample(
    struct vibration_app *app,
    float acceleration_g,
    struct vibration_result *result)
{
    app->samples[app->write_index++] = acceleration_g;
    if (app->write_index < VIB_WINDOW_SIZE) {
        return false;
    }

    app->write_index = 0u;
    vibration_extract_features(app->samples, result->features);
    result->class_id = vibration_model_predict(result->features);
    result->sequence = ++app->sequence;
    return true;
}

const char *vibration_class_name(int class_id)
{
    static const char *const names[] = {
        "healthy", "imbalance", "misalignment", "bearing_fault"
    };
    if (class_id < 0 || class_id >= 4) {
        return "unknown";
    }
    return names[class_id];
}
